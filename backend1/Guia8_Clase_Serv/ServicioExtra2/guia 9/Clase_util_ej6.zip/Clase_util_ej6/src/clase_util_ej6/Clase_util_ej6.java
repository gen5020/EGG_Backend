
package clase_util_ej6;

import Servicio.CursoServicio;


public class Clase_util_ej6 {

    public static void main(String[] args) {
CursoServicio cs=new CursoServicio();
cs.crearCurso();
cs.calcularGananciaSemanal();

        }
    }


