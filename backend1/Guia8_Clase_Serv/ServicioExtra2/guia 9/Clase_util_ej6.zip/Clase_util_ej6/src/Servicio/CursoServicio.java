
package Servicio;

import Entidad.Curso;
import java.util.Scanner;


public class CursoServicio {
    
    Scanner sc = new Scanner(System.in);
    Curso cs=new Curso();
    
    public void cargarAlumnos() {
        String[] alumnos = new String[3];
        for (int i = 0; i < 3; i++) {
            System.out.println("Ingrese el alumno");
            alumnos[i] = sc.next();
        }
        cs.setAlumnos(alumnos);
            }
    
public Curso crearCurso()  {  
    System.out.println("ingrese el nombre del curso ");
   cs.setNombreCurso(sc.next());
    System.out.println("ingrese la cantidad de horas por dia");
cs.setCantidadHorasPorDia(sc.nextInt());
    System.out.println("ingrese la cantidad de horas por semana");
    cs.setCantidadDiasPorSemana(sc.nextInt());
    System.out.println("ingrese el turno");
 cs.setTurno(sc.next());
    System.out.println("ingrese el precio de la hora");
  cs.setPrecioPorHora(sc.nextDouble());
  cargarAlumnos();
  return cs;
}

public void calcularGananciaSemanal(){ 
    Double ganancia;
    ganancia=cs.getCantidadHorasPorDia()*cs.getPrecioPorHora()*3*cs.getCantidadDiasPorSemana();
    System.out.println("La ganancia en una semana de curso es "+ganancia);
    
}
     
}
