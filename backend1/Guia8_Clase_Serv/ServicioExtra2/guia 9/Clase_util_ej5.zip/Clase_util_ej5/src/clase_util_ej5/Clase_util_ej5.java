
package clase_util_ej5;

import Entidades.Persona;
import Servicio.PersonaService;


public class Clase_util_ej5 {

    public static void main(String[] args) {

        PersonaService fs=new PersonaService();
       Persona p=new Persona();
       
       fs.crearPersona(p);
       fs.calcularEdad(p);
         if (fs.menorQue(p)==true) {
            System.out.println("Es mayor"); 
        } else {
            System.out.println("Es menor"); 
        }
       
        fs.mostrarPersona(p);
                                  
                        
    }

}
