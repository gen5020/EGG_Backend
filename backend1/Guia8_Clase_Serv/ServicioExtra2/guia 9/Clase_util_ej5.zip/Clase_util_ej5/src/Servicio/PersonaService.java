
package Servicio;

import Entidades.Persona;
import java.util.Date;
import java.util.Scanner;


public class PersonaService {
    Scanner sc = new Scanner(System.in);

    public Persona crearPersona(Persona p) {
        System.out.println("ingrese su nombre");
        String nombre = sc.next();
        p.setNombre(nombre);
        System.out.println("ingrese dia de nacimiento");
        int dia = sc.nextInt();
        System.out.println("ingrese dia de mes");
        int mes = sc.nextInt();
        System.out.println("ingrese dia de año");
        int anio = sc.nextInt();
        Date fecha1 = new Date(anio - 1900, mes - 1, dia);
        p.setFechaNacimiento(fecha1);
        return p;
    } 
  public int calcularEdad (Persona p) {  
      Date fecha1=p.getFechaNacimiento();
      Date fecha2 = new Date();
      int edad= fecha2.getYear() - fecha1.getYear();
      return edad;
        }
  
  public boolean menorQue (Persona p){
  boolean respuesta;
   System.out.println("Ingrese la edad");
        int edad = sc.nextInt();
        int edadpersona=calcularEdad(p);
        if (edadpersona<edad) {
          respuesta=true;
            return respuesta;
        }
        respuesta=false;
     return  respuesta; 
  }
  public void mostrarPersona (Persona p) {
        System.out.println("El nombre de la persona es " +p.getNombre());
      System.out.println("El dia de nacimiento es " +p.getFechaNacimiento());
        System.out.println("La edad es " +calcularEdad(p));
  }    
  
}
