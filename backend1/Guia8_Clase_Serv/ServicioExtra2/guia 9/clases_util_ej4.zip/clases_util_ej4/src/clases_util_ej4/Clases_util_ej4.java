
package clases_util_ej4;

import Servicios.FechaService;
import java.util.Date;


public class Clases_util_ej4 {

    public static void main(String[] args) {
       FechaService fs =new FechaService();
       Date fecha1= fs.fechaNacimiento();
        System.out.println("La fecha de nacimiento es " + fecha1);  
         Date fecha2= fs.fechaActual();
              System.out.println("La edad del usuario es" + fs.diferencia(fecha1, fecha2));
               
    }

}
