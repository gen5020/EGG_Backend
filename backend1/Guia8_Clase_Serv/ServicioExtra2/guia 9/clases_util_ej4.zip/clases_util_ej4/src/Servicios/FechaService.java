
package Servicios;

import java.util.Date;
import java.util.Scanner;


public class FechaService {
    
    Date fecha= new Date ();
    Scanner sc = new Scanner(System.in);
    public Date fechaNacimiento(){
        System.out.println("ingrese dia de nacimiento");
        int dia=sc.nextInt(); 
           System.out.println("ingrese dia de mes");
        int mes=sc.nextInt();
           System.out.println("ingrese dia de año");
        int anio=sc.nextInt();
    Date fecha1=new Date(anio-1900,mes-1,dia);
    return fecha1;
    } 
    
     public Date fechaActual()  {
    Date fecha2=new Date();
    return fecha2;
    }
    
     public int diferencia(Date fecha1,Date fecha2)  {
         return fecha2.getYear()-fecha1.getYear();
         
     }
     
}
